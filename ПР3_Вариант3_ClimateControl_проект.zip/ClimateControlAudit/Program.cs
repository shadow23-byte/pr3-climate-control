using System.Text;
using ClimateControlAudit;

byte[] demoKey = Encoding.UTF8.GetBytes("climate-control-demo-key-32-bytes!");
DateTimeOffset now = DateTimeOffset.UtcNow;
var service = new ClimateReadingService(demoKey, TimeSpan.FromMinutes(5), () => now);
var valid = new ClimateReading("sensor-03", 22_500, now.ToUnixTimeSeconds());
string signature = ClimateReadingService.CreateSignature(valid, demoKey);
var stale = valid with { TimestampUnixSeconds = now.AddMinutes(-10).ToUnixTimeSeconds() };
var high = valid with { TemperatureMilliCelsius = 100_000 };

var checks = new (string Name, bool Passed)[]
{
    ("Корректное показание с HMAC", service.TryAccept(valid, signature)),
    ("Подмена температуры отклонена", !service.TryAccept(valid with { TemperatureMilliCelsius = 31_000 }, signature)),
    ("Отсутствие подписи отклонено", !service.TryAccept(valid, "")),
    ("Устаревшая метка времени отклонена", !service.TryAccept(stale, ClimateReadingService.CreateSignature(stale, demoKey))),
    ("Температура вне диапазона отклонена", !service.TryAccept(high, ClimateReadingService.CreateSignature(high, demoKey)))
};
foreach (var check in checks)
    Console.WriteLine($"{(check.Passed ? "PASS" : "FAIL")} | {check.Name}");
Console.WriteLine($"Итог: {checks.Count(x => x.Passed)}/{checks.Length}; принято записей: {service.AcceptedReadings.Count}");
return checks.All(x => x.Passed) ? 0 : 1;
