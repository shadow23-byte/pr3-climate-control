using System.Globalization;
using System.Security.Cryptography;
using System.Text;

namespace ClimateControlAudit;

/// <summary>Проверяет подлинность и допустимость показаний датчиков климат-контроля.</summary>
public sealed class ClimateReadingService
{
    private readonly byte[] _hmacKey;
    private readonly long _allowedAgeSeconds;
    private readonly Func<DateTimeOffset> _clock;
    private readonly List<ClimateReading> _acceptedReadings = [];

    /// <summary>Создаёт службу проверки показаний.</summary>
    public ClimateReadingService(byte[] hmacKey, TimeSpan allowedAge, Func<DateTimeOffset> clock)
    {
        ArgumentNullException.ThrowIfNull(hmacKey);
        ArgumentNullException.ThrowIfNull(clock);
        if (hmacKey.Length < 32) throw new ArgumentException("Ключ должен содержать не менее 32 байт.", nameof(hmacKey));
        if (allowedAge <= TimeSpan.Zero || allowedAge.TotalSeconds > long.MaxValue)
            throw new ArgumentOutOfRangeException(nameof(allowedAge));
        _hmacKey = (byte[])hmacKey.Clone();
        _allowedAgeSeconds = (long)allowedAge.TotalSeconds;
        _clock = clock;
    }

    /// <summary>Возвращает снимок принятых показаний.</summary>
    public IReadOnlyList<ClimateReading> AcceptedReadings
    {
        get { lock (_acceptedReadings) return _acceptedReadings.ToArray(); }
    }

    /// <summary>Принимает показание после проверки диапазона, времени и HMAC.</summary>
    public bool TryAccept(ClimateReading? reading, string? signatureHex)
    {
        if (reading is null || !IsValidSensorId(reading.SensorId) ||
            reading.TemperatureMilliCelsius is < -40_000 or > 85_000 ||
            string.IsNullOrWhiteSpace(signatureHex)) return false;

        long nowUnix = _clock().ToUnixTimeSeconds();
        if (reading.TimestampUnixSeconds < nowUnix - _allowedAgeSeconds ||
            reading.TimestampUnixSeconds > nowUnix + _allowedAgeSeconds) return false;

        byte[] suppliedSignature;
        try { suppliedSignature = Convert.FromHexString(signatureHex); }
        catch (FormatException) { return false; }
        if (suppliedSignature.Length != 32) return false;
        byte[] expectedSignature = HMACSHA256.HashData(_hmacKey, Serialize(reading));
        if (!CryptographicOperations.FixedTimeEquals(suppliedSignature, expectedSignature)) return false;

        lock (_acceptedReadings) _acceptedReadings.Add(reading);
        return true;
    }

    /// <summary>Вычисляет подпись для учебной проверки. Ключ в рабочей системе хранят отдельно от исходного кода.</summary>
    public static string CreateSignature(ClimateReading reading, byte[] hmacKey)
    {
        ArgumentNullException.ThrowIfNull(reading);
        ArgumentNullException.ThrowIfNull(hmacKey);
        return Convert.ToHexString(HMACSHA256.HashData(hmacKey, Serialize(reading)));
    }

    private static byte[] Serialize(ClimateReading reading) => Encoding.UTF8.GetBytes(
        string.Create(CultureInfo.InvariantCulture,
            $"{reading.SensorId}|{reading.TemperatureMilliCelsius}|{reading.TimestampUnixSeconds}"));

    private static bool IsValidSensorId(string? sensorId) =>
        !string.IsNullOrWhiteSpace(sensorId) && sensorId.Length <= 64 &&
        sensorId.All(c => c is >= 'a' and <= 'z' or >= 'A' and <= 'Z' or >= '0' and <= '9' or '-' or '_');
}
