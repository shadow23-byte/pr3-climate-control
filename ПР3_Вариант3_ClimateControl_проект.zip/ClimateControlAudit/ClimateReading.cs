namespace ClimateControlAudit;

/// <summary>Показание климатического датчика до проверки подлинности.</summary>
/// <param name="SensorId">Идентификатор датчика.</param>
/// <param name="TemperatureMilliCelsius">Температура в тысячных долях градуса Цельсия.</param>
/// <param name="TimestampUnixSeconds">Время измерения в секундах Unix.</param>
public sealed record ClimateReading(
    string SensorId,
    int TemperatureMilliCelsius,
    long TimestampUnixSeconds);
